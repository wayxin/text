#!python
# -*- coding:utf-8 -*-
'''
本目录主要保存各公用类库,不涉及具体业务逻辑,各系统可公用
目前只考虑 py2.6 ~ py2.7 版本的使用，不保证兼容其它版本

Created on 2015/11/17
Updated on 2016/8/9
@author: Holemar
'''